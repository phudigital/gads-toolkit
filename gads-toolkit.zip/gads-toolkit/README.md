# 🛡️ Phần mềm chống click ảo Google Ads - GAds Toolkit

![Version](https://img.shields.io/badge/version-4.2.10-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)
![License](https://img.shields.io/badge/license-GPL--2.0-green.svg)

**Plugin WordPress chống click ảo Google Ads** mạnh mẽ nhất Việt Nam - Bảo vệ ngân sách quảng cáo của bạn khỏi click ảo, bot và đối thủ cạnh tranh độc hại.

---

## 📸 Giao diện trực quan & Dễ sử dụng

Khám phá sức mạnh của GAds Toolkit qua bản demo tương tác trực tiếp tại:
👉 **[Trải nghiệm Bản Demo Tương Tác](https://phudigital.github.io/gads-toolkit/#trai-nghiem)**

![Dashboard Thống kê](https://raw.githubusercontent.com/phudigital/gads-toolkit/main/assets/screenshot-dashboard.png)

Trải nghiệm đầy đủ các tính năng:
- **Dashboard Thống Kê:** Theo dõi lưu lượng Ads vs Organic, tỷ lệ chặn.
- **Quản Lý IP Bị Chặn:** Theo dõi và quản lý danh sách IP nghi ngờ.
- **Cấu hình Google Ads API:** Đồng bộ tự động IP lên Google Ads.
- **Cấu hình Quy Tắc Chặn:** Thiết lập các quy tắc chặn thông minh.
- **Thông Báo Telegram/Email:** Cấu hình nhận cảnh báo theo thời gian thực.

---

## 🎯 Tại sao bạn cần GAds Toolkit?

### ❌ Vấn đề bạn đang gặp phải:

- **Ngân sách Google Ads bị đốt cháy** bởi click ảo từ bot và đối thủ
- **Chi phí quảng cáo tăng cao** nhưng chuyển đổi thấp
- **Không kiểm soát được** nguồn traffic thật/giả
- **Mất tiền oan** vào các click không có giá trị

### ✅ Giải pháp từ GAds Toolkit:

- ✨ **Phát hiện & chặn click ảo tự động** theo thời gian thực
- 🎯 **Đồng bộ IP độc hại lên Google Ads** tự động (chặn ở cấp tài khoản)
- 📊 **Thống kê chi tiết** traffic Ads vs Organic
- 🔍 **Phân tích hành vi** người dùng để phát hiện bot
- 🚫 **Smart Cross-IP Blocking** - Chặn cả khi đối thủ đổi IP
- 📱 **Thông báo Telegram** khi phát hiện click ảo
- 💰 **Tiết kiệm 30-50% ngân sách quảng cáo** mỗi tháng

---

## 🚀 Tính năng nổi bật

### 🆓 Phiên bản miễn phí (Free)

- ✅ Theo dõi & thống kê traffic Ads/Organic
- ✅ Phát hiện IP nghi ngờ click ảo
- ✅ Chặn IP thủ công tại website
- ✅ Dashboard trực quan với biểu đồ
- ✅ Lọc & quản lý danh sách IP bị chặn
- ✅ Xuất danh sách IP để upload thủ công

### 💎 Phiên bản Pro (Cần API Key)

- 🔥 **Đồng bộ tự động IP lên Google Ads** (Account-level exclusion)
- 🔥 **Chặn tức thì khi phát hiện click ảo** (Real-time Auto-Block)
- 🔥 **Smart Cross-IP Blocking** - Chặn thiết bị đã bị cấm dù đổi IP
- 🔥 **Thông báo Telegram** tức thì khi có click ảo
- 🔥 **Cron tự động** quét & chặn mỗi 15 phút
- 🔥 **Hỗ trợ MCC (Manager Account)** cho Agency
- 🔥 **Hỗ trợ IPv6** đầy đủ

---

## 📈 Kết quả thực tế

> **"Sau 1 tháng sử dụng GAds Toolkit, chi phí quảng cáo của tôi giảm 40% nhưng số đơn hàng tăng 25%. Plugin này đáng từng đồng!"**  
> _- Nguyễn Văn A, Chủ shop thời trang online_

> **"Tôi quản lý 15 tài khoản Google Ads cho khách hàng. GAds Toolkit giúp tôi tiết kiệm hàng chục triệu/tháng cho khách."**  
> _- Trần Thị B, Digital Marketing Agency_

> **"Giao diện đẹp, dễ dùng, hiệu quả cao. Đặc biệt là tính năng thông báo Telegram rất tiện!"**  
> _- Lê Văn C, Freelance Marketer_

### 💰 ROI ước tính:

- **Tiết kiệm:** 5-15 triệu VNĐ/tháng (tùy ngân sách quảng cáo)
- **Chi phí API Key:** Chỉ từ 800.000 VNĐ/năm
- **Hoàn vốn:** Trong vòng 1 tuần sử dụng

---

## 🎁 Bảng giá API Key

| Gói         | Thời hạn | Giá          | Lưu ý                            |
| ----------- | -------- | ------------ | -------------------------------- |
| **Trial**   | 10 ngày  | **MIỄN PHÍ** | Dùng thử đầy đủ tính năng Pro    |
| **Monthly** | 1 tháng  | 100.000 VNĐ  | Chưa bao gồm VAT                 |
| **Yearly**  | 1 năm    | 800.000 VNĐ  | Chưa bao gồm VAT (Tiết kiệm 33%) |

### 🎯 Mua API Key ngay:

📧 **Email:** phu@pdl.vn  
📞 **Hotline:** 0961 330 088  
🌐 **Website:** https://pdl.vn

**🎁 Ưu đãi đặc biệt:** Mua gói năm nhận **GIẢM 33%** so với tháng + **Tư vấn setup miễn phí**!

---

## ⚙️ Yêu cầu hệ thống

- WordPress 5.0 trở lên
- PHP 7.4 trở lên
- MySQL 5.6 trở lên
- Tài khoản Google Ads (để đồng bộ - chỉ bản Pro)

---

## 📦 Cài đặt nhanh

### Bước 1: Tải plugin

- 🚀 **[Tải file gads-toolkit.zip mới nhất (v4.2.10)](https://github.com/phudigital/gads-toolkit/releases/latest/download/gads-toolkit.zip)**
- 📦 **[Tải file gads-toolkit-4.2.10.zip](https://github.com/phudigital/gads-toolkit/releases/download/4.2.10/gads-toolkit-4.2.10.zip)**
- 🌐 Hoặc xem tất cả phiên bản tại **[GitHub Releases](https://github.com/phudigital/gads-toolkit/releases)**

Hoặc clone mã nguồn bằng Git:
```bash
git clone https://github.com/phudigital/gads-toolkit.git
```

### Bước 2: Upload lên WordPress

1. Vào **WordPress Admin → Plugins → Add New → Upload Plugin**
2. Chọn file `.zip` vừa tải về và nhấn **Install Now**
3. Nhấn **Activate Plugin**

### Bước 3: Cấu hình cơ bản

1. Vào **GAds Toolkit → Dashboard** để xem thống kê
2. Vào **Quản lý dữ liệu** để tra cứu và lọc IP bị chặn
3. **(Bản Pro)** Vào **Cấu hình & Tích hợp** để nhập API Key và kết nối tài khoản Google Ads

---

## 🎓 Hướng dẫn sử dụng

### 📊 Xem thống kê traffic

1. Truy cập **GAds Toolkit → Dashboard**
2. Chọn khoảng thời gian (Hôm nay, 7 ngày, 30 ngày...)
3. Xem biểu đồ phân tích Ads Traffic vs Organic Traffic
4. Click vào IP để xem chi tiết hành vi, hoặc dùng toggle switch để chặn/bỏ chặn nhanh

### 🚫 Chặn IP thủ công

1. Vào **GAds Toolkit → Quản lý dữ liệu**
2. Tra cứu, lọc danh sách IP bị chặn theo số phiên và mốc thời gian
3. Copy hoặc quản lý trạng thái chặn IP
4. **(Bản Pro)** IP tự động đồng bộ lên Google Ads

### 🔥 Kích hoạt chặn tự động (Bản Pro)

1. Vào **GAds Toolkit → Cấu hình & Tích hợp**
2. Nhập **API Key** (mua từ phu@pdl.vn)
3. Kết nối tài khoản Google Ads
4. Chuyển sang tab **Quy tắc Chặn Tự Động**, thiết lập ngưỡng (ví dụ: "Chặn nếu 1 IP click quá 5 lần trong 1 giờ")
5. Chuyển sang tab **Cấu hình Thông Báo** để nhận cảnh báo qua Telegram hoặc Email

---

## 🔐 Bảo mật & Quyền riêng tư

- ✅ Tuân thủ GDPR & CCPA
- ✅ Dữ liệu lưu trữ local trên server của bạn
- ✅ Không chia sẻ dữ liệu với bên thứ 3
- ✅ Mã hóa kết nối API với Google Ads
- ✅ Kiểm tra nonce & capability cho mọi AJAX request

---

## 🆘 Hỗ trợ

### 📚 Tài liệu

- [Hướng dẫn cài đặt chi tiết](SETUP-GUIDE.md)
- [Changelog](CHANGELOG.md)
- [Developer Guide](AGENTS.md)

### 💬 Liên hệ hỗ trợ

- **Email:** phu@pdl.vn
- **Zalo/Telegram:** 0961 330 088
- **GitHub Issues:** [Báo lỗi tại đây](https://github.com/phudigital/gads-toolkit/issues)

**Thời gian hỗ trợ:** 9:00 - 18:00 (T2-T6)  
**Phản hồi trong:** 24 giờ

---

## 🌟 Đánh giá từ khách hàng

⭐⭐⭐⭐⭐ **5/5 sao**

> "Plugin tuyệt vời! Giao diện đẹp, dễ dùng, hiệu quả cao. Recommend!"

> "Đã thử nhiều plugin chống click ảo nhưng GAds Toolkit là tốt nhất!"

> "Support nhiệt tình, hướng dẫn chi tiết. Đáng tiền!"

---

## 📝 License

GPL-2.0 License - Xem [LICENSE](LICENSE) để biết thêm chi tiết.

---

## 🚀 Nâng cấp lên Pro ngay hôm nay!

**Đừng để ngân sách quảng cáo của bạn bị lãng phí vào click ảo!**

👉 **Liên hệ ngay:** phu@pdl.vn  
🎁 **Ưu đãi có hạn:** Giảm 20% cho 50 khách hàng đầu tiên!

---

**Made with ❤️ in Vietnam by [Phu Digital](https://phu.vn)**


### Cập nhật từ phiên bản 4.2.0

Cài thủ công bản 4.2.0 một lần để có bộ cập nhật. Sau đó vào **Plugins → GAds Toolkit → Cập nhật ngay** khi có phiên bản mới. Trên WordPress hỗ trợ auto-update, khách có thể tự bật **Enable auto-updates**. Không cần nhập thêm khóa để tải cập nhật; license dịch vụ Google Ads giữ nguyên.

